package com.CampaniaCovidFree.CampaniaCovidFree.Model.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.RisultatoTampone;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository.RisultatoTamponeRepository;

@Service
public class RisultatoTamponeService {

	@Autowired
	private RisultatoTamponeRepository ris;
	
	public void SaveRisultato(RisultatoTampone risultato) {
		
		ris.save(risultato);
		
	}
}
