package com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Paziente;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Tampone;



public class TamponeRepositoryImpl implements TamponeRepositoryCustom{
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public Tampone findTamponeById(Integer Id) {
		
		Tampone tampone=null;
		try {
	        String q = "SELECT t FROM Tampone t WHERE t.ID LIKE :IdParam";
	        Query query = entityManager.createQuery(q);
	        query.setParameter("IdParam", Id);
	        tampone = (Tampone) query.getSingleResult();
	       
	}catch(NoResultException e) {
		System.out.println("ecco2 ");
	}
		return tampone;
	}
	}


