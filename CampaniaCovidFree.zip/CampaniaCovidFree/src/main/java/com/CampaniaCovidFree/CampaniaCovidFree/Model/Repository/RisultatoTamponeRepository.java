package com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository;

import java.sql.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Paziente;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.RisultatoTampone;

@Repository
public interface RisultatoTamponeRepository  extends JpaRepository<RisultatoTampone,Date>{

}
