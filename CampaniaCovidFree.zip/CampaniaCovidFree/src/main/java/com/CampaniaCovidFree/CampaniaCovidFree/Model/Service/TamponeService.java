package com.CampaniaCovidFree.CampaniaCovidFree.Model.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Paziente;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Tampone;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository.TamponeRepository;

@Service
public class TamponeService {
	
	@Autowired
	private TamponeRepository tam;
	
	public Tampone CercaTampone(Integer Id_tampone) {
		
		return tam.findTamponeById(Id_tampone);
		
	}
	
	public void SaveTampone(Tampone t) {
		tam.save(t);
	}

}
