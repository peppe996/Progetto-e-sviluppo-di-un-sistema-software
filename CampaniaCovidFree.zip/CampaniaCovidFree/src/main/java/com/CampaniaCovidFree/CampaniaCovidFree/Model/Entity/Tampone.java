package com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity;

import java.util.Date;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Tamponi")
@SequenceGenerator(name="seq", initialValue=13,allocationSize=1)
public class Tampone {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	private Integer ID;
	@Column
	private Date DataPrenotazione;
	
	@OneToOne(cascade= {CascadeType.MERGE})
	@JoinColumn(name="risultato")
	private RisultatoTampone risultato;
	
	public Tampone() {
		
	}
	
	public Tampone(Date data,Paziente p,ASL asl) {
		DataPrenotazione=data;
		paziente=p;
		Asl=asl;
	}
	
	public Integer getID() {
		return ID;
	}

	public void setID(Integer iD) {
		ID = iD;
	}

	public Date getDataPrenotazione() {
		return DataPrenotazione;
	}

	public void setDataPrenotazione(Date dataPrenotazione) {
		DataPrenotazione = dataPrenotazione;
	}

	public RisultatoTampone getRisultato() {
		return risultato;
	}

	public void setRisultato(RisultatoTampone risultato) {
		this.risultato = risultato;
	}

	public Paziente getPaziente() {
		return paziente;
	}

	public void setPaziente(Paziente paziente) {
		this.paziente = paziente;
	}

	public ASL getAsl() {
		return Asl;
	}

	public void setAsl(ASL asl) {
		Asl = asl;
	}

	@ManyToOne
	@JoinColumn(name="paziente")
	private Paziente paziente;
	
	@ManyToOne
	@JoinColumn(name="asl")
	private ASL Asl;

}
