package com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.MedicoDiBase;

@Repository
public interface MedicoDiBaseRepository extends JpaRepository<MedicoDiBase,String>,MedicoDiBaseRepositoryCustom{

}
