package com.CampaniaCovidFree.CampaniaCovidFree.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.DipendenteASL;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.MedicoDiBase;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Paziente;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Service.DipendenteASLService;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Service.MedicoDiBaseService;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Service.PazienteService;

@Controller
@SessionAttributes("dipendente")
public class HomeController{
	
	@Autowired
	private PazienteService paz;
	
	@Autowired
	private MedicoDiBaseService med;
	@Autowired
	private DipendenteASLService dip;
	
	@GetMapping(value="/")
	public String home(){
		return "home";
	}
	
	
	@RequestMapping(value ="/accesso" ,method = RequestMethod.GET)
	public String accedi(Model model){ 
		
		InfoUtente info=new InfoUtente();
		model.addAttribute("info",info);
		return "accesso";
	} 
	
	@RequestMapping(value= "/verificaDati",method= RequestMethod.POST)
	public String verificaDati(@ModelAttribute("info") InfoUtente info,Model model) {
		
		if(info.getTipologia().compareTo("paziente")==0 || info.getTipologia().compareTo("Paziente")==0){
			
			Paziente pass=paz.VerificaPaziente(info.getEmail());
			
			if(pass!=null && (pass.getPassword().compareTo(info.getPassword())==0)) {
				
				model.addAttribute("nome", pass.getNome());
				return "homepaziente";
			}
			
		}else if(info.getTipologia().compareTo("medico di base")==0 || info.getTipologia().compareTo("Medico Di Base")==0) {
			
			MedicoDiBase medico=med.VerificaPaziente(info.getEmail());
			
			if(medico!=null && (medico.getPassword().compareTo(info.getPassword())==0)) {
				
				model.addAttribute("nome", medico.getNome());
				return "homemedicodibase";
			}
		}else if(info.getTipologia().compareTo("Dipendente asl")==0 || info.getTipologia().compareTo("Dipendente ASL")==0) {
			
			DipendenteASL dipendente=dip.VerificaDipendente(info.getEmail());
			
			if(dipendente!=null && (dipendente.getPassword().compareTo(info.getPassword())==0)){
				model.addAttribute("dipendente", dipendente);
				
				return "homedipendenteASL";
			
			}
		}
		return "errore";
	}
	
	@ModelAttribute("dipendente")
	public DipendenteASL nuovoDipendente(DipendenteASL d) {
		DipendenteASL dipe=new DipendenteASL(d.getNome(),d.getCognome(),d.getEmail(),d.getPassword(),d.getAsl(),d.getMatricola());
		return dipe;
	}
}
