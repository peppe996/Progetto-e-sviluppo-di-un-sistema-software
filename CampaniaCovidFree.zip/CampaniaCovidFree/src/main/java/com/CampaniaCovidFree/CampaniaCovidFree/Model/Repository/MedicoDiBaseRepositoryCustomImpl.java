package com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.MedicoDiBase;

@Repository
@Transactional
public class MedicoDiBaseRepositoryCustomImpl implements MedicoDiBaseRepositoryCustom{
	
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public MedicoDiBase findMedico(String email){
		
		MedicoDiBase med=null;
		try {
	        String q = "SELECT p FROM MedicoDiBase p WHERE p.Email LIKE :emailParam";
	        Query query = entityManager.createQuery(q);
	        query.setParameter("emailParam", email);
	        med = (MedicoDiBase) query.getSingleResult();
	       
	}catch(NoResultException e) {
		System.out.println("ecco2 ");
	}
		return med;
	}

}
