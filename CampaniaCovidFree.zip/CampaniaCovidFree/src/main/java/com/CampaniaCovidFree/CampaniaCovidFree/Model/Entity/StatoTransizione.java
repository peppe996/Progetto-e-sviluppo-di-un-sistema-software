package com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity;

public class StatoTransizione extends StatoPaziente{

	public StatoTransizione(Paziente p) {
		super(p);
	}
	
	public void AggiornaStato(String esito) {
		if(esito.compareTo("positivo")==0) {
			paziente.setStatoPaziente(new StatoPositivo(paziente));
			paziente.setStato("positivo");
		}else {
			paziente.setStatoPaziente(new StatoNegativo(paziente));
			paziente.setStato("negativo");
			paziente.setInQuarantena(0);
		}
			
	}
}
