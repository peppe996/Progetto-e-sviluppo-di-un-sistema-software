package com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository;

import java.util.List;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Paziente;

public interface PazienteRepositoryCustom {
	
	public Paziente findPaziente(String Email);
		

}
