package com.CampaniaCovidFree.CampaniaCovidFree.Model.Service;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.RisultatoTampone;

public interface RisultatoTamponeRepositoryCustom {
	
	public void SaveRisultatoTampone(RisultatoTampone risultato);

}
