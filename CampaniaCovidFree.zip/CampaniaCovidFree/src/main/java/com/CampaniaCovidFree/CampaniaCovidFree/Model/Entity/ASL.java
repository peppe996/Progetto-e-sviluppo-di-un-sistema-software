package com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="ASL")
public class ASL {
	
	public ASL() {
		
	}
	
	@Id
	private String NomeCentro;
	@Column
	private String Indirizzo;
	@OneToMany(cascade= {CascadeType.ALL})
	@JoinColumn(name="asl")
	private Set<Tampone> Tamponi;
	@OneToMany(cascade= {CascadeType.ALL})
	@JoinColumn(name="asl")
	private Set<Paziente> ListaPazienti;
	
	@OneToMany(cascade= {CascadeType.ALL})
	@JoinColumn(name="asl")
	private Set<DipendenteASL> ListaDipendenti;
	
	@OneToMany(cascade= {CascadeType.ALL})
	@JoinColumn(name="asl")
	private Set<MedicoDiBase> ListaMediciDiBase;
	
	
	public ASL(String nomeCentro, String indirizzo) {
		NomeCentro = nomeCentro;
		Indirizzo = indirizzo;
	}
	
	public String getNomeCentro() {
		return NomeCentro;
	}
	public void setNomeCentro(String nomeCentro) {
		NomeCentro = nomeCentro;
	}
	public String getIndirizzo() {
		return Indirizzo;
	}
	public void setIndirizzo(String indirizzo) {
		Indirizzo = indirizzo;
	}
	

}
