package com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity;

public class StatoPositivo extends StatoPaziente{


	public StatoPositivo(Paziente p) {
		super(p);
	}
	
	public void AggiornaStato(String esito) {
		if(esito.compareTo("negativo")==0) {
			paziente.setStatoPaziente(new StatoTransizione(paziente));
			paziente.setStato("transizione");
		}
		
	}
}
