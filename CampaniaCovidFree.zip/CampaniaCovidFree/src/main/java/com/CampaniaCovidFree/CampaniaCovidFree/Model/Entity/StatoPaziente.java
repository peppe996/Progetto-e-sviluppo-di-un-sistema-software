package com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity;

public abstract class StatoPaziente {
	
	protected Paziente paziente;

	public abstract void AggiornaStato(String Esito);
	
	public StatoPaziente(Paziente p) {
		paziente=p;
	}
}
