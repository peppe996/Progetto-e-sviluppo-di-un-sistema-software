package com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="pazienti")
public class Paziente extends Utente{
	
	static Integer id=6;
	
	public Paziente(String nome, String cognome, String email, String password, ASL asl,String indirizzo,int quarant) {
		super(nome, cognome, email, password, asl);
		// TODO Auto-generated constructor stub
		
		Indirizzo=indirizzo;
		InQuarantena=quarant;
		stato="negativo";
		Id_Famiglia=id;
		id=id+1;
		//Familiari=null;
	}
	
	public Paziente() {
		super();
	}

	@Id
	private String Email;
	@Column
	private String Indirizzo;
	@Column
	private String Nome;
	@Column
	private String Cognome;
	@Column
	private String Password;
	@Column 
	private Integer InQuarantena;
	@Column
	private String stato;
	@Column
	private Integer Id_Famiglia;
	
	@ManyToOne
	@JoinColumn(name="medico")
	private MedicoDiBase Medico;
	
	@ManyToOne
	@JoinColumn(name="asl")
	private ASL Asl;
	
	@OneToMany(cascade= {CascadeType.ALL})
	@JoinColumn(name="paziente")
	private Set<Tampone> ListaTamponi;
	
	@OneToMany(cascade= {CascadeType.ALL})
	@JoinColumn(name="paziente")
	private Set<Sintomo> ListaSintomi;
	
	@Transient
	private StatoPaziente Stato;
	
	public void Aggiorna_stato(String esito) {
		
		if(this.stato.compareTo("negativo")==0) {
			Stato=new StatoNegativo(this);
		}if(this.stato.compareTo("positivo")==0) {
			Stato=new StatoPositivo(this);
		}else
			Stato=new StatoTransizione(this);
		
		Stato.AggiornaStato(esito);
		
		
		
	}
	
	public Integer getId_Famiglia() {
		return Id_Famiglia;
	}

	public void setId_Famiglia(Integer id_Famiglia) {
		Id_Famiglia = id_Famiglia;
	}

	public void setStato(String stato) {
		this.stato = stato;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getIndirizzo() {
		return Indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		Indirizzo = indirizzo;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getCognome() {
		return Cognome;
	}

	public void setCognome(String cognome) {
		Cognome = cognome;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public Integer getInQuarantena() {
		return InQuarantena;
	}

	public void setInQuarantena(Integer inQuarantena) {
		InQuarantena = inQuarantena;
	}

	public MedicoDiBase getMedico() {
		return Medico;
	}

	public void setMedico(MedicoDiBase medico) {
		Medico = medico;
	}

	public ASL getAsl() {
		return Asl;
	}

	public void setAsl(ASL asl) {
		Asl = asl;
	}

	public Set<Tampone> getListaTamponi() {
		return ListaTamponi;
	}

	public void setListaTamponi(Set<Tampone> listaTamponi) {
		ListaTamponi = listaTamponi;
	}

	public Set<Sintomo> getListaSintomi() {
		return ListaSintomi;
	}

	public void setListaSintomi(Set<Sintomo> listaSintomi) {
		ListaSintomi = listaSintomi;
	}

	public StatoPaziente getStatoPaziente() {
		return Stato;
	}

	public void setStatoPaziente(StatoPaziente stato) {
		Stato = stato;
	}

	public String getStato() {
		return stato;
	}	

}
