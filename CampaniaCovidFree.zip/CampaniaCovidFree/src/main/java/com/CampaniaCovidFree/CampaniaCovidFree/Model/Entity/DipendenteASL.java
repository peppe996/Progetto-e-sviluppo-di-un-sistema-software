package com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="DipendentiASL")
public class DipendenteASL extends Utente{

	public DipendenteASL(String nome, String cognome, String email, String password, ASL asl, String matricola) {
		super(nome, cognome, email, password, asl);
		// TODO Auto-generated constructor stub
		Matricola=matricola;
	}
	
	public DipendenteASL() {
		super();
	}

	public String getMatricola() {
		return Matricola;
	}

	public void setMatricola(String matricola) {
		Matricola = matricola;
	}
	
	@Id
	private String Email;
	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getCognome() {
		return Cognome;
	}

	public void setCognome(String cognome) {
		Cognome = cognome;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public ASL getAsl() {
		return Asl;
	}

	public void setAsl(ASL asl) {
		Asl = asl;
	}

	public Set<RisultatoTampone> getListaRisultati() {
		return ListaRisultati;
	}

	public void setListaRisultati(Set<RisultatoTampone> listaRisultati) {
		ListaRisultati = listaRisultati;
	}

	@Column
	private String Matricola;
	@Column
	private String Nome;
	@Column
	private String Cognome;
	
	@Column
	private String Password;
	
	@ManyToOne
	@JoinColumn(name="asl")
	private ASL Asl;
	
	@OneToMany(cascade= {CascadeType.MERGE})
	@JoinColumn(name="dipendente_asl")
	private Set<RisultatoTampone> ListaRisultati;
	

}
