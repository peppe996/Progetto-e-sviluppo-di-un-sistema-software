package com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Paziente;


@Repository
@Transactional
public class PazienteRepositoryImpl implements PazienteRepositoryCustom{

	
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public Paziente findPaziente(String email){
		
		Paziente pass=null;
		try {
	        String q = "SELECT p FROM Paziente p WHERE p.Email LIKE :emailParam";
	        Query query = entityManager.createQuery(q);
	        query.setParameter("emailParam", email);
	        pass = (Paziente) query.getSingleResult();
	       
	}catch(NoResultException e) {
		System.out.println("ecco2 ");
	}
		return pass;
	}
	
	
}
