package com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Tampone;

@Repository
public interface TamponeRepository extends JpaRepository<Tampone,Integer>,TamponeRepositoryCustom{

}
