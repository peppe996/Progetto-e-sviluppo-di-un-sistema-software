package com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Tampone;

public interface TamponeRepositoryCustom {

	public Tampone findTamponeById(Integer Id);
	

}
