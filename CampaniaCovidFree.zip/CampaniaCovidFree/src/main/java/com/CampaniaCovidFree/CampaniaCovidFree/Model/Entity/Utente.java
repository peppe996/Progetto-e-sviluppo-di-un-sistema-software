package com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity;

import javax.persistence.Column;
import javax.persistence.Id;

public abstract class Utente {
	
	
	private String Nome;
	private String Cognome;
	private String Email;
	private String Password;
	
	private ASL Asl;
	
	public ASL getAsl() {
		return Asl;
	}

	public void setAsl(ASL asl) {
		Asl = asl;
	}

	public Utente(String nome,String cognome,String email,String password,ASL asl) {
		Nome=nome;
		Cognome=cognome;
		Email=email;
		Password=password;
		Asl=asl;
	}
	
	public Utente() {
		
	}
	
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public String getCognome() {
		return Cognome;
	}
	public void setCognome(String cognome) {
		Cognome = cognome;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
	

}
