package com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.DipendenteASL;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Paziente;

public interface DipendenteASLRepositoryCustom {
	
	public DipendenteASL findDipendente(String Email);

}
