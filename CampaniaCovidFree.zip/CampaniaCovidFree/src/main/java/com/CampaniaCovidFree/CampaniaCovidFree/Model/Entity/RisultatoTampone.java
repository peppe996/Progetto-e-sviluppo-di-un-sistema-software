package com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="risultati_tampone")
public class RisultatoTampone {
	
	@Id
	private Integer Id_Risultato;
	@Column
	private Date DataInserimento;
	
	@Column
	private String Esito;
	
	@OneToOne
	@JoinColumn(name="tampone")
	private Tampone tampone;
	
	@ManyToOne
	@JoinColumn(name="dipendente_asl")
	private DipendenteASL Dipendente;
	
	public Integer getId_Risultato() {
		return Id_Risultato;
	}


	public void setId_Risultato(Integer id_Risultato) {
		Id_Risultato = id_Risultato;
	}


	public Date getDataInserimento() {
		return DataInserimento;
	}


	public void setDataInserimento(Date dataInserimento) {
		DataInserimento = dataInserimento;
	}


	public String getEsito() {
		return Esito;
	}


	public void setEsito(String esito) {
		Esito = esito;
	}


	public Tampone getTampone() {
		return tampone;
	}


	public void setTampone(Tampone tampone) {
		this.tampone = tampone;
	}


	public DipendenteASL getDipendente() {
		return Dipendente;
	}


	public void setDipendente(DipendenteASL dipendente) {
		Dipendente = dipendente;
	}
	
	
	public RisultatoTampone(Date data,String esito,Integer id,Tampone tampone,DipendenteASL dipendente) {
		this.DataInserimento=data;
		this.Esito=esito;
		this.Id_Risultato=id;
		this.tampone=tampone;
		this.Dipendente=dipendente;
	}
	
	public RisultatoTampone() {
		
	}

}
