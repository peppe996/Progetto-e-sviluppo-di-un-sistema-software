package com.CampaniaCovidFree.CampaniaCovidFree.Model.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.MedicoDiBase;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Paziente;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository.MedicoDiBaseRepository;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository.PazienteRepository;

@Service
public class MedicoDiBaseService {
	
	@Autowired
	private MedicoDiBaseRepository med;
	
	public MedicoDiBase VerificaPaziente(String email) {
		
		
		MedicoDiBase medico=null;
		try {
		 medico=med.findMedico(email);
		
		}catch(IllegalArgumentException e ) {
			
		}
		 return medico;
	}

}
