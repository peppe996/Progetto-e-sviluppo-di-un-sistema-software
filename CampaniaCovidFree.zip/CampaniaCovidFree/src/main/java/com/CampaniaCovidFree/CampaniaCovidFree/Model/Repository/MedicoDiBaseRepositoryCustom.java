package com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.MedicoDiBase;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Paziente;

public interface MedicoDiBaseRepositoryCustom {
	
	public MedicoDiBase findMedico(String Email);

}
