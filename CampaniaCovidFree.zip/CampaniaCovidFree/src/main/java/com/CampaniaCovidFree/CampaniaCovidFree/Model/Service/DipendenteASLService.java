package com.CampaniaCovidFree.CampaniaCovidFree.Model.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.DipendenteASL;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository.DipendenteASLRepository;


@Service
public class DipendenteASLService {
	
	@Autowired
	private DipendenteASLRepository dip;
	
	public DipendenteASL VerificaDipendente(String Email) {
		
		DipendenteASL dipendente=null;
		try {
		 dipendente=dip.findDipendente(Email);
		
		}catch(IllegalArgumentException e ) {
			
		}
		 return dipendente;
	}
	}


