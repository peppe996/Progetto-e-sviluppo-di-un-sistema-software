package com.CampaniaCovidFree.CampaniaCovidFree.Controller;

public class Risultato {

}
