package com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity;

import java.sql.Date;

import javax.persistence.*;

@Entity
@Table(name="resoconti_giornalieri")
public class ResocontoGiornaliero {
	
	@Id
	private Date Data;
	@Column
	private Integer TamponiEffettuati;
	@Column
	private Integer TamponiPositivi;

}
