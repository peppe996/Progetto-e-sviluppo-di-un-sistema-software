package com.CampaniaCovidFree.CampaniaCovidFree.Controller;

import java.util.Calendar;


import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.DipendenteASL;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Paziente;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.RisultatoTampone;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.StatoNegativo;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.StatoPositivo;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Tampone;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Service.PazienteService;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Service.RisultatoTamponeService;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Service.TamponeService;

@Controller
@SessionAttributes("dipendente")
public class ControllerDipendenteASL {
	
	@Autowired
	private TamponeService tam;
	@Autowired
	private RisultatoTamponeService ris;
	@Autowired
	private PazienteService paz;
	
	@RequestMapping(value ="/InserisciRisultato", method=RequestMethod.GET)
	public String PaginaInserisci(Model model) {
		
		RisultatoTampone risultato=nuovoRisultato();
		model.addAttribute("risultato", risultato);
		return "inserisci";
	}
	
	@GetMapping(value="/homeDipendente")
	public String homeDipendente(@ModelAttribute("dipendente") DipendenteASL dipendente) {
		return "homedipendenteASL";
	}
	
	@RequestMapping(value ="/risultatoinserito", method=RequestMethod.POST)
	public String InserisciRisultatoTampone(@SessionAttribute("dipendente") DipendenteASL dipendente,@ModelAttribute("risultato") RisultatoTampone risultato,Model model) {
		
		risultato.setDipendente(dipendente);
		
		boolean ok=false;
		
		Tampone tampone=tam.CercaTampone(risultato.getId_Risultato());
		
		if(tampone!=null && risultato.getDataInserimento() instanceof Date && ((risultato.getEsito().compareToIgnoreCase("positivo")==0) 
				|| (risultato.getEsito().compareToIgnoreCase("negativo")==0) )) {
			
			if(tampone.getRisultato()==null && 
					tampone.getDataPrenotazione().before(risultato.getDataInserimento()) &&
					 dipendente.getAsl().getNomeCentro().compareTo(tampone.getPaziente().getAsl().getNomeCentro())==0)
				ok=true;
		}
		
		
		if(ok) {
			risultato.setTampone(tampone);
			
			tampone.setRisultato(risultato);
			Paziente paziente=tampone.getPaziente();
			
			tam.SaveTampone(tampone);
			paziente.Aggiorna_stato(risultato.getEsito());
			ris.SaveRisultato(risultato);
			if(paziente.getStatoPaziente() instanceof StatoNegativo) {
				
			return "RisultatoInserito";
			
			}
			if(paziente.getStatoPaziente() instanceof StatoPositivo){
				Calendar cal = Calendar.getInstance();    
				
				cal.setTime(risultato.getDataInserimento());  
				
				cal.add( Calendar.DATE, 7 );
				
				Date data=cal.getTime();
				
				cal.add(Calendar.DATE, -1);
				Date stamp=cal.getTime();
				
				PrenotaTampone(data,paziente);
				model.addAttribute("data", new java.sql.Date(stamp.getTime()));
				
				
				return "RisultatoInseritoETampone";
			}else {
				Calendar cal = Calendar.getInstance();    
				
				cal.setTime(risultato.getDataInserimento());  
				
				cal.add( Calendar.DATE, 3 );
				
				Date data=cal.getTime();
				
				cal.add(Calendar.DATE, -1);
				Date stamp=cal.getTime();
				
				PrenotaTampone(data,paziente);
				
				model.addAttribute("data", new java.sql.Date(stamp.getTime()));
				
				return "RisultatoInseritoETampone";
			}
			}else if(tampone==null) {
				return "TamponeNonTrovato";
		}else {
		
		model.addAttribute("errore", (String)"Input errati: potresti aver sbagliato la data,l'esito, cercato di inserire un risultato già esistente oppure non hai il permesso di inserire il risultato perchè il paziente appartiene ad un'altra ASL");
		return "inserisci";
		}
	}
	
	public void PrenotaTampone(Date d,Paziente p) {
		p.setInQuarantena(1);
		Tampone t=new Tampone(d,p,p.getAsl());
		tam.SaveTampone(t);
		
	}
	
	@ModelAttribute("dipendente")
	public DipendenteASL nuovoDipendente(DipendenteASL d) {
		DipendenteASL dipe=new DipendenteASL(d.getNome(),d.getCognome(),d.getEmail(),d.getPassword(),d.getAsl(),d.getMatricola());
		return dipe;
	}
	
	@ModelAttribute("risultato")
	public RisultatoTampone nuovoRisultato() {
		return new RisultatoTampone();
	}
}
