package com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity;

import java.sql.Date;

import javax.persistence.*;

@Entity
@Table(name="sintomi")
public class Sintomo {
	
	@Id
	private String Nome;
	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getIntensita() {
		return Intensita;
	}

	public void setIntensita(String intensita) {
		Intensita = intensita;
	}

	public Date getDataInserimento() {
		return DataInserimento;
	}

	public void setDataInserimento(Date dataInserimento) {
		DataInserimento = dataInserimento;
	}

	public Paziente getPaziente() {
		return paziente;
	}

	public void setPaziente(Paziente paziente) {
		this.paziente = paziente;
	}

	@Column
	private String Intensita;
	@Column
	private Date DataInserimento;
	
	@ManyToOne
	@JoinColumn(name="paziente")
	private Paziente paziente;
	 
	public Sintomo(String nome,String intensita,Date data) {
		this.DataInserimento=data;
		this.Intensita=intensita;
		this.Nome=nome;
	}
	
	public Sintomo() {
		
	}
	
}
