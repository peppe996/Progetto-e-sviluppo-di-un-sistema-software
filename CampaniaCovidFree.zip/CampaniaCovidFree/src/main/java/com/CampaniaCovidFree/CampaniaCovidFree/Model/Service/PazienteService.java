package com.CampaniaCovidFree.CampaniaCovidFree.Model.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Paziente;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository.PazienteRepository;

@Service
public class PazienteService {
	
	@Autowired
	private PazienteRepository paz;
	
	public Paziente VerificaPaziente(String email) {
		
		
		Paziente pass=null;
		try {
		 pass=paz.findPaziente(email);
		
		}catch(IllegalArgumentException e ) {
			
		}
		 return pass;
	}
	
	public void savePaziente(Paziente p) {
		
		paz.save(p);
	}

}
