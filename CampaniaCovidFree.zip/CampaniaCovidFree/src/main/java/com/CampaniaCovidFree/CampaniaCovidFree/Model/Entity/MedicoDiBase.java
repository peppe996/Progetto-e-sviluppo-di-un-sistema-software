package com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.mapping.List;



@Entity
@Table(name="medicidibase")
public class MedicoDiBase extends Utente{

	public MedicoDiBase(String nome, String cognome, String email, String password, ASL asl,String indirizzo) {
		super(nome, cognome, email, password, asl);
		// TODO Auto-generated constructor stub
		IndirizzoSede=indirizzo;
	}
	
	public MedicoDiBase() {
		super();
	}
	
	@Id
	private String Email;
	@Column
	private String IndirizzoSede;
	@Column
	private String Nome;
	@Column
	private String Cognome;
	@Column
	private String Password;
	
	@ManyToOne
	@JoinColumn(name="asl")
	private ASL Asl;
	
	@OneToMany
	@JoinColumn(name="medico")
	private Set<Paziente> ListaPazienti;

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getIndirizzoSede() {
		return IndirizzoSede;
	}

	public void setIndirizzoSede(String indirizzoSede) {
		IndirizzoSede = indirizzoSede;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getCognome() {
		return Cognome;
	}

	public void setCognome(String cognome) {
		Cognome = cognome;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public ASL getAsl() {
		return Asl;
	}

	public void setAsl(ASL asl) {
		Asl = asl;
	}

	public Set<Paziente> getListaPazienti() {
		return ListaPazienti;
	}

	public void setListaPazienti(Set<Paziente> listaPazienti) {
		ListaPazienti = listaPazienti;
	}

}
