package com.CampaniaCovidFree.CampaniaCovidFree.Model.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.DipendenteASL;
import com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity.Paziente;

@Repository
@Transactional
public class DipendenteASLRepositoryCustomImpl implements DipendenteASLRepositoryCustom{
	
	@PersistenceContext
	EntityManager entityManager;
	
	public DipendenteASL findDipendente(String email){
		
		DipendenteASL dip=null;
		try {
	        String q = "SELECT p FROM DipendenteASL p WHERE p.Email LIKE :emailParam";
	        Query query = entityManager.createQuery(q);
	        query.setParameter("emailParam", email);
	        dip = (DipendenteASL) query.getSingleResult();
	       
	}catch(NoResultException e) {
		System.out.println("ecco2 dip");
	}
		return dip;
	}
	

}
