package com.CampaniaCovidFree.CampaniaCovidFree.Model.Entity;

public class StatoNegativo extends StatoPaziente{
	
	public StatoNegativo(Paziente p) {
		super(p);
	}
	
	public void AggiornaStato(String esito) {
		
		paziente.setInQuarantena(0);
		
		if(esito.compareTo("positivo")==0) {
			
			paziente.setStatoPaziente(new StatoPositivo(paziente));
			paziente.setStato("positivo");
			paziente.setInQuarantena(1);
		}
		
	}

}
